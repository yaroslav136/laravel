<?php echo e($slot); ?>

<?php /**PATH C:\php_projects\metro\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>