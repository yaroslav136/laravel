<?php $__env->startSection('content'); ?>
    <div class="mb-5 d-flex flex-row move-right">
        <?php echo $__env->make('layouts.ecard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="ms-5 border border-danger border-2 rounded-4 d-flex flex-column justify-content-center align-items-center p-2">
            <form action="<?php echo e(route('cards.delete', $card->id)); ?>" method="post" class="mb-4">
                <?php echo csrf_field(); ?>
                <?php echo method_field('delete'); ?>
                <input class="btn btn-danger" type="submit" value="Удалить карту">
            </form>
            <p id="card-balance"><b>Баланс на карте: </b><?php echo e($card->balance); ?></p>
        </div>
    </div>
    <div>
        <p class="col-6 block rounded-4 p-3 h4 text-center" id="pay-succes" style="background-color: #88ff88; display: none;">Оплата произведена успешно!</p>
        <h1>Пополнить баланс проездной карты</h1>
        <form class="col-6" id="card-form" data-action="<?php echo e(route('cards.pay')); ?>" method="POST" enctype="multipart/form-data" novalidate>
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="card" class="form-label">Транспортная карта</label>
                <select class="form-select" type="text" name="card_id" id="card">
                    <?php $__currentLoopData = $cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ecard): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option
                            <?php if($ecard->id === $card->id): ?>
                            selected
                            <?php endif; ?>
                            value="<?php echo e($ecard->id); ?>">&#128179 <?php echo e($ecard->type." ".number_format($ecard->number, 0, ' ', ' ')); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <option value="other-card">Пополнить другую карту</option>
                </select>



                <p hidden id="card_id-error" class="text-danger text-small mt-1"></p>
            </div>
            <div class="mb-3">
                <label for="sum-pay" class="form-label">Сумма пополнения</label>
                <input class="form-control" type="number" name="sum" id="sum-pay" placeholder="Введите сумму">



                <p hidden id="sum-error" class="text-danger text-small mt-1"></p>
            </div>
            <div class="mb-3">
                <label for="methodPay" class="form-label">Способ оплаты</label>
                <select class="form-select" type="text" name="typePay" id="methodPay" disabled>
                    <option selected value="bank-card">Банковская карта</option>
                </select>
                <input hidden name="typePay" value="bank-card"/>



                <p hidden id="typePay-error" class="text-danger text-small mt-1"></p>
            </div>
            <?php echo $__env->make('cards.pay_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <button type="button" id="checksum" class="btn btn-primary launch">Ввести реквизиты</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\php_projects\metro\resources\views/cards/show.blade.php ENDPATH**/ ?>