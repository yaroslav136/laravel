<?php $__env->startSection('content'); ?>
    <h2 class="mb-4">Мои обращения</h2>
    <div class="col-12 border-1 border-bottom pb-1">
        <a href="<?php echo e(route('claims.create')); ?>" class="pb-2 text-decoration-none text-dark fw-bold">Новое обращение</a>
        <a href="<?php echo e(route('claims.index')); ?>" class="border-bottom border-1 border-danger pb-2 ms-3 text-decoration-none text-dark fw-bold">Мои обращения</a>
    </div>


    <?php $__currentLoopData = $appeals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appeal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="d-flex flex-column col-9 bg-light p-4 mb-5 rounded-3">
            <div class=" d-flex d-row">
                <div class="col-4 mt-4">
                    <div class="col-12 mb-4">
                        <p class="text-small fw-bold form-label">ФИО</p>
                        <p class="text-wrap-break"><?php echo e($appeal->fio); ?></p>
                    </div>
                    <div class="col-12 mb-4">
                        <p class="text-small fw-bold form-label">Адрес</p>
                        <p class="text-wrap-break"><?php echo e($appeal->address); ?></p>
                    </div>
                    <div class="col-12 mb-4">
                        <p class="text-small fw-bold form-label">Номер телефона</p>
                        <p><?php echo e($appeal->phone); ?></p>
                    </div>
                    <div class="col-12 mb-4">
                        <p class="text-small fw-bold form-label">E-mail</p>
                        <p class="text-wrap-break"><?php echo e($appeal->email); ?></p>
                    </div>
                    <div class="col-12 mb-4">
                        <p class="text-small fw-bold form-label">Тип обращения</p>
                        <p><?php echo e($appeal->appeal_type->appeal_type); ?></p>
                    </div>
                    <div class="col-12 mb-4">
                        <p class="text-small fw-bold form-label">Категория</p>
                        <p><?php echo e($appeal->category->category); ?></p>
                    </div>
                    <div class="col-12 mb-4">
                        <p class="text-small fw-bold form-label">Подкатегория</p>
                        <p><?php echo e($appeal->subcategory->subcategory); ?></p>
                    </div>
                </div>
                <div class="mt-4 ms-5 col-7">
                    <div class="mb-4">
                        <p class="text-small fw-bold form-label">Полное описание ситуации</p>
                        <textarea readonly rows="5" type="text" class="form-control" id="description"><?php echo e($appeal->description); ?></textarea>
                    </div>
                    <div class="mb-4">
                        <p class="text-small fw-bold form-label">Дата</p>
                        <p><?php echo e($appeal->date); ?></p>
                    </div>
                    <?php if($appeal->img_path): ?>
                        <div class="mb-4">
                            <p class="text-small fw-bold form-label">Изображение</p>
                            <img class="mt-2" style="max-width: 300px; max-height: 300px;" src="<?php echo e('storage/'.$appeal->img_path); ?>"/>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="d-flex justify-content-between">
                <div class="<?php echo e($appeal->status->id === 1 ? "bg-warning" : "bg-success"); ?> p-3 rounded-4 text-white me-5 fw-bold">
                    <p class="m-0 p-0" style="font-size: 13px"><?php echo e($appeal->status->status); ?></p>
                </div>
                <form action="<?php echo e(route('claims.delete', $appeal->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <input class="btn btn-danger p-2 h-100 rounded-4" style="font-size: 13px" type="submit"
                           value="Удалить заявление"/>
                </form>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\php_projects\metro\resources\views/claims/index.blade.php ENDPATH**/ ?>