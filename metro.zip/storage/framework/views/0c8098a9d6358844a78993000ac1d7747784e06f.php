<?php $__env->startSection('content'); ?>
    <h2><?php echo e(mb_strtoupper($article->title)); ?></h2>
    <img height="150" width="150" class="float-start my-3 me-3" src="<?php echo e(asset("storage/".$article->img)); ?>">
    <p class="mt-4"><?php echo e($article->created_at->format("d.m.Y")); ?></p>
    <?php echo $article->content; ?>

    <a href="<?php echo e(url()->previous()); ?>" class="text-decoration-none h5" style="color: #3fa675">← Обратно к списку</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\php_projects\metro\resources\views/news/show.blade.php ENDPATH**/ ?>