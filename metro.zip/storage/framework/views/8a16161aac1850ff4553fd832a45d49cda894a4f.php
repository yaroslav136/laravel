<?php $__env->startSection('content'); ?>
    <div class="mb-5">
        <form action="<?php echo e(route('review.store')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-floating">
                <input name="content" type="text" class="form-control" id="floatingPassword" placeholder="Введите имя пользователя">
                <label for="floatingPassword">Текст отзыва</label>
            </div>
            <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-danger text-small mt-1"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <button type="submit" class="mt-4 btn btn-primary">Добавить отзыв</button>
        </form>
    </div>
    <ul class="list-group">
        <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bg-light p-3 rounded mb-4 row">
                <div class="col-10">
                    <p class="h3"><?php echo e($review->name); ?></p>
                    <p class="lead text-wrap-break"><?php echo e($review->content); ?></p>
                </div>
                <?php if(auth()->user()->id === $review->authorId): ?>

                    <div class="col-2 text-xl-end">
                        <p class="text-muted p-2 m-0"><?php echo e($review->created_at->format('Y-m-d H:i')); ?></p>
                        <a class="d-block mb-3" href="<?php echo e(route('review.edit', $review->id)); ?>">Редактировать</a>
                        <input class="float-end d-block" id="delete_review" type="checkbox" data-id="<?php echo e($review->id); ?>">





                    </div>
                <?php endif; ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <div class="d-flex flex-row justify-content-between">
            <?php echo e($reviews->links('pagination::bootstrap-4')); ?>

            <button type="button" id="remAll" data-route="<?php echo e(route('review.removeSelected')); ?>" class="btn btn-danger">Удалить выделенные</button>
        </div>
    </ul>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\php_projects\metro\resources\views/review/index_create.blade.php ENDPATH**/ ?>