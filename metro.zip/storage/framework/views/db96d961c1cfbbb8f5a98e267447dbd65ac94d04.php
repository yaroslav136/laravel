<?php $__env->startSection('content'); ?>
    <div class="mb-5">
        <form action="<?php echo e(route('review.update', $review->id)); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('patch'); ?>
            <div class="form-floating">
                <input name="content" value="<?php echo e($review->content); ?>" type="text" class="form-control" id="floatingPassword" placeholder="Введите имя пользователя">
                <label for="floatingPassword">Текст отзыва</label>
            </div>
            <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-danger text-small"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <button type="submit" class="mt-4 btn btn-primary">Изменить</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\php_projects\metro\resources\views/review/edit.blade.php ENDPATH**/ ?>