<?php $__env->startSection('content'); ?>
    <h2>Официальное обращение</h2>
    <div class="col-12 border-1 border-bottom pb-1">
        <a class="border-bottom border-1 border-danger pb-2 text-decoration-none text-dark fw-bold">Новое обращение</a>
        <a class="ms-3 text-decoration-none text-dark fw-bold">Мои обращения</a>
    </div>
    <div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\php_projects\metro\resources\views/claims/create.blade.php ENDPATH**/ ?>
