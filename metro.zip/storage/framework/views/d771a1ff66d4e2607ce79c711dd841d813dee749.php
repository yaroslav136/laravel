<?php $__env->startSection('content'); ?>
    <ul class="list-group">
        <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div>$review->id</div>
            <div class="bg-light p-3 rounded position-relative">
                <p class="h3">name</p>
                <p class="lead text-wrap-break">content</p>
                <p class="text-muted position-absolute top-0 end-0 p-2">time</p>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\php_projects\metro\resources\views/layouts/index_create.blade.php ENDPATH**/ ?>
