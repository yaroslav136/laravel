<?php $__env->startSection('content'); ?>
    <h1>Добавить проездную карту</h1>
    <form class="col-6" action="<?php echo e(route('cards.store')); ?>" method="post" autocomplete="off">
        <?php echo csrf_field(); ?>
        <label for="card" class="form-label">Номер карты</label>
        <input type="text" autocomplete="off" name="number" value="<?php echo e(old('number')); ?>" id="card" class="form-control" aria-describedby="cardHelpBlock" placeholder="0123456789">
        <?php $__errorArgs = ['number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger">вы непрвильно ввели номер карты</p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <button type="submit" class="mt-3 btn btn-primary">Добавить</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\php_projects\metro\resources\views/cards/create.blade.php ENDPATH**/ ?>