<?php $__env->startSection('content'); ?>
    <div id="map" class="map"></div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="https://api-maps.yandex.ru/2.1/?lang=ru_RU&amp;apikey=2e215ac5-6655-410e-bb14-9021a866cf91" type="text/javascript"></script>
    <script src="<?php echo e(asset('js/ymaps.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\php_projects\metro\resources\views/news/index.blade.php ENDPATH**/ ?>