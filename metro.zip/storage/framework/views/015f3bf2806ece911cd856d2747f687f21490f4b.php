<?php $__env->startSection('content'); ?>
    <h1 hidden>Главная страница</h1>
    <h2>Новости</h2>
    <div>
        <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-8 d-flex flex-row rounded-4 border border-1 my-3">
                <div class="p-2">
                    <img width="150" height="150" src="<?php echo e(asset("storage/".$article->img)); ?>">
                </div>
                <div class="mx-3 my-2">
                    <p class="text-muted text-small"><?php echo e($article->created_at->format("d.m.Y")); ?></p>
                    <a href="<?php echo e(route('news.show', $article->id)); ?>" class="h5" style="color: #3fa675">
                        <p><?php echo e($article->title); ?></p>
                        <p>Подробнее...</p>
                    </a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div>
            <?php echo e($articles->links('pagination::bootstrap-4')); ?>

        </div>
    </div>

    <h2 class="mt-5">Карта станций</h2>
    <div id="map" class="map"></div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="https://api-maps.yandex.ru/2.1/?lang=ru_RU&amp;apikey=2e215ac5-6655-410e-bb14-9021a866cf91" type="text/javascript"></script>
    <script defer src="<?php echo e(asset('js/ymaps.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\php_projects\metro\resources\views/index.blade.php ENDPATH**/ ?>