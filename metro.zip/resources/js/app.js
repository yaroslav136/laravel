import './bootstrap';
import './slick.min'
import './slick_slider'
import './script'
